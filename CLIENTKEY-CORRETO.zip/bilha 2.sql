use clientes_db;

create TABLE clientes(
	id int PRIMARY KEY auto_increment,
	nome VARCHAR(255),
    cpf VARCHAR(255),
    email VARCHAR(255),
    telefone VARCHAR(255),
    adress VARCHAR (255),
    statuscl VARCHAR(255),
    usuario_relacionado INT NOT NULL, users
    FOREIGN KEY (usuario_relacionado) references users(id)
);

SELECT * from clientes;
