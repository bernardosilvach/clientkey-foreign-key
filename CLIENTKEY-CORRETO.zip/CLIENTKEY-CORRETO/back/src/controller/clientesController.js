const connection = require('../config/db')
const dotenv = require('dotenv').config();

async function storeClientes(request, response) {
    const params = Array(
        request.body.nome,
        request.body.cpf,
        request.body.email,
        request.body.telefone,
        request.body.endereco,
        request.body.status,
        
    )

    const query = "INSERT INTO clientes(nome, cpf, email, telefone, adress, statuscl, id) VALUES(?, ?, ?, ?, ?, ?, ?)";
    
    connection.query(query, params, (err, results) => {
        if(results) {
            response.status(200).json({
                success: true,
                message: "Sucesso!",
                data: results
            })
        } else {
            response.status(400).json({
                success: false,
                message: "Erro!",
                sql: err,
            })
        }
    })
}

module.exports = {
    storeClientes
}