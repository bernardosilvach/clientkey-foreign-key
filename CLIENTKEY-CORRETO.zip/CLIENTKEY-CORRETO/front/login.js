var botaologin = document.getElementById('botaologin')

botaologin.onclick = async function(e) {
    e.preventDefault()


    var email = document.getElementById('email').value
    var senha = document.getElementById('senha').value

    if (!email || !senha) {
        alert('Preencha todos os campos!')
        return false
    } else {
        let data = {email,senha}

        const response = await fetch('http://localhost:3000/api/store/login', {
            method: 'POST',
            headers: { "Content-type": "application/json;charset=UTF-8" },
            body: JSON.stringify(data)
        })

        let content = await response.json()

        if (content.success) {
            alert('Sucesso')

            console.log(content)
            //salvar os dados do usuario logado no localstorage

            window.location.href = 'principal.html'
        } else {
            alert('Erro')
        }
    }
}