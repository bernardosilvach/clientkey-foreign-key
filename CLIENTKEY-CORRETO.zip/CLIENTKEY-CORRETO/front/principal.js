let abrir_form = document.getElementById("abrir_form")

abrir_form.addEventListener("click", function () {
    let modal_teste = document.getElementById("id01")

    modal_teste.style.display = "block"
})

let close = document.getElementById("close")

close.addEventListener("click", function () {
    let modal_teste = document.getElementById("id01")
    modal_teste.style.display = "none"
})


async function handleSubmit(event) {
    event.preventDefault();

    let nome = document.getElementById("nome").value;
    let cpf = document.getElementById("cpf").value;
    let email = document.getElementById("email").value;
    let telefone = document.getElementById("telefone").value;
    let endereco = document.getElementById("endereco").value;
    let status = document.getElementById("status").value;
    //aqui tu vai criar uma variavel id_usuario = o id que tá no localstorage

    const data = {
        nome,
        cpf,
        email,
        telefone,
        endereco,
        status,
        //id
    }


    const response = await fetch('http://localhost:3000/api/store/clientes', {
        method: 'POST',
        headers: { "Content-type": "application/json;charset=UTF-8" },
        body: JSON.stringify(data)
    })

    let content = await response.json()

    if (content.success) {

        var card = document.createElement("div");
        card.classList.add("card"); // Adiciona a classe 'card' ao elemento

        // Define o conteúdo HTML do card com os valores capturados do formulário
        card.innerHTML = `
                <h3>${nome}</h3>
                <p>CPF: ${cpf}</p>
                <p>Email: ${email}</p>
                <p>Telefone: ${telefone}</p>
                <p>Endereço: ${endereco}</p>
                <p>Status: ${status}</p>
            `;

        document.querySelector(".interiorbaixo").appendChild(card);

        document.getElementById("myForm").reset();

        let modal_teste = document.getElementById("id01")

        modal_teste.style.display = 'none'
    } else {
        alert("Erro ao cadastrar cliente!");
    }

}